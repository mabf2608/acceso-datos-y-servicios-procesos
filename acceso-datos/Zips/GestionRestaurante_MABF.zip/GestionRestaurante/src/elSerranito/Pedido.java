package elSerranito;

import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Pedido implements Serializable {
	
	private static final long serialVersionUID = 1L;
	private static final String FICHERO = "pedidos.dat";
	
	private int id;
	private String cliente;
	private String plato;
	private double precio;
	private String fecha;
	
	public Pedido(int id, String cliente, String plato, double precio, String fecha)
	{
		this.id = id;
		this.cliente = cliente;
		this.plato = plato;
		this.precio = precio;
		this.fecha = fecha;
	}

	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}

	public String getCliente() {
		return cliente;
	}
	public void setCliente(String cliente) {
		this.cliente = cliente;
	}

	public String getPlato() {
		return plato;
	}
	public void setPlato(String plato) {
		this.plato = plato;
	}

	public double getPrecio() {
		return precio;
	}
	public void setPrecio(double precio) {
		this.precio = precio;
	}

	public String getFecha() {
		return fecha;
	}
	public void setFecha(String fecha) {
		this.fecha = fecha;
	}
	
	public static Pedido[] listar() {
    	File f = new File(FICHERO);
    	
    	if (!f.exists()) {
    		return new Pedido[0];
    	}
    	
    	List<Pedido> pList = new ArrayList<Pedido>();
    	
    	try(ObjectInputStream ois = new ObjectInputStream(new FileInputStream(f))){
    		
    		while(true) {
    			Pedido p = (Pedido) ois.readObject();
    			pList.add(p);
    		}
    		
    	}catch(EOFException e) {

    	}catch(IOException | ClassNotFoundException e) {
    		e.printStackTrace();
    	}
    	
    	return pList.toArray(new Pedido[0]);
    }
	
	public static Pedido buscarPedidoEnFichero(String nombre)
	{
		File f = new File(FICHERO);
		
		if (!f.exists())
			return null;
		
		try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(f))){
			while(true) {
				Pedido p = (Pedido) ois.readObject();
				if (p.getCliente().trim().equalsIgnoreCase(nombre))
					return p;
			}
		} catch(EOFException e){
    		return null;
    	} catch(IOException | ClassNotFoundException e) {
    		e.printStackTrace();
    		return null;
    	}
	}
	
	public void grabar(File fichero)
	{
		List<Pedido> pList = new ArrayList<Pedido>();
		Pedido[] pedidos = Pedido.listar();
		
		if (pedidos != null)
			pList.addAll(Arrays.asList(pedidos));
		
		pList.add(this);
		try(ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(fichero)))
		{
			for (Pedido p : pList) 
			{
				oos.writeObject(p);
			}
		}catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	@Override
	public String toString() {
		return "Pedido [ID = " + id + ", Cliente = " + cliente + ", Plato = " + plato + ", Precio = " + precio + ", Fecha = " + fecha + "]";
	}
}
